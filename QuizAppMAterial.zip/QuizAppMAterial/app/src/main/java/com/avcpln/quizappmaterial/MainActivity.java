package com.avcpln.quizappmaterial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.mobsandgeeks.saripaar.ValidationError;
import com.mobsandgeeks.saripaar.Validator;
import com.mobsandgeeks.saripaar.annotation.DecimalMax;
import com.mobsandgeeks.saripaar.annotation.DecimalMin;
import com.mobsandgeeks.saripaar.annotation.NotEmpty;
import com.mobsandgeeks.saripaar.annotation.Password;

import java.util.List;

public class MainActivity extends AppCompatActivity implements Validator.ValidationListener {
    Button login;
    TextView register;
    TextInputLayout mobilee,pass;
    @NotEmpty
    @DecimalMin(value = 1000000000,message = "Should be 10 digits")
           // @DecimalMax(value = 10,message = "Should be 10 digits")

    TextInputEditText mobile;

    @NotEmpty
    @Password(message = "Password must contain Alphanumeric 6 gigit",scheme = Password.Scheme.ALPHA_NUMERIC)
    TextInputEditText password;
     Validator validator;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getSupportActionBar().hide();
        mobile=findViewById(R.id.tiMobile);
        password=findViewById(R.id.tiPassword);
        mobilee=findViewById(R.id.Mobile);
        pass=findViewById(R.id.etPassword);
        register=findViewById(R.id.tvRegister);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Registration.class));
            }
        });


        validator = new Validator(this);
        validator.setValidationListener((Validator.ValidationListener) this);

        login=findViewById(R.id.btn_Login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getError()==null){
                    pass.setError(null);
                }if(mobile.getError()==null){
                    mobilee.setError(null);
                }
                validator.validate();

            }

        });

    }

    @Override
    public void onValidationSucceeded() {
        Toast.makeText(this, "Yay! we got it right!", Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onValidationFailed(List<ValidationError> errors) {
        for (ValidationError error : errors) {
            View view = error.getView();
            String message = error.getCollatedErrorMessage(this);

            // Display error messages ;)
            if (view==mobile) {
                mobilee.setError(message);

            }
             if(view==password) {
                pass.setError(message);
            }

/*

                    if (password.getText().toString().length() == 0 ) {
                        pass.setError("Password should not be empty");

                    } else if(password.getText().toString().length() < 6) {
                        pass.setError("Password must contain 6 char");

                        String pass = "enter correct password";
                        password.setError(pass);
                    }else {
                        pass.setError(message);
                    }


                if (mobile.getText().toString().length() == 0 ) {
                    mobilee.setError("Mobile should not be empty");

                } else if(mobile.getText().toString().length() < 10) {
                    mobilee.setError("Password must contain 10 char");

                        String pass = "enter correct password";
                        password.setError(pass);
                }else {
                    mobilee.setError(message);
                }


*/







        }
    }
    }


